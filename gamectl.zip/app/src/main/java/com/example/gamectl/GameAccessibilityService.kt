package com.example.gamectl

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlin.math.min

class GameAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GameAccessibilityService? = null
        fun act(dir: String) { instance?.perform(dir) }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun perform(dir: String) {
        val m = resources.displayMetrics
        val cx = m.widthPixels / 2f
        val cy = m.heightPixels / 2f
        val d = min(m.widthPixels, m.heightPixels) * 0.25f
        val path = Path()
        var dur = 100L
        when (dir) {
            "left" -> { path.moveTo(cx + d, cy); path.lineTo(cx - d, cy) }
            "right" -> { path.moveTo(cx - d, cy); path.lineTo(cx + d, cy) }
            "up" -> { path.moveTo(cx, cy + d); path.lineTo(cx, cy - d) }
            "down" -> { path.moveTo(cx, cy - d); path.lineTo(cx, cy + d) }
            "tap" -> { path.moveTo(cx, cy); dur = 50L }
            else -> return
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        dispatchGesture(g, null, null)
    }
}
