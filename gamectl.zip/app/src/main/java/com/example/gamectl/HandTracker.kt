package com.example.gamectl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.abs
import kotlin.math.max

class HandTracker(ctx: Context, private val onSwipe: (String) -> Unit) {
    private val landmarker: HandLandmarker
    private val hist = ArrayDeque<Triple<Long, Float, Float>>()
    private var lastFire = 0L
    private var lastTs = 0L

    init {
        val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
        val opts = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { r, _ -> onResult(r) }
            .setErrorListener { }
            .build()
        landmarker = HandLandmarker.createFromOptions(ctx, opts)
    }

    fun detect(proxy: ImageProxy) {
        val bmp = proxy.toBitmap()
        val m = Matrix()
        m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
        m.postScale(-1f, 1f) // front camera mirror
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        var ts = SystemClock.uptimeMillis()
        if (ts <= lastTs) ts = lastTs + 1
        lastTs = ts
        landmarker.detectAsync(BitmapImageBuilder(out).build(), ts)
    }

    private fun onResult(r: HandLandmarkerResult) {
        val now = SystemClock.uptimeMillis()
        if (r.landmarks().isEmpty()) { hist.clear(); return }
        val p = r.landmarks()[0][9] // palm centre
        hist.addLast(Triple(now, p.x(), p.y()))
        while (hist.isNotEmpty() && now - hist.first().first > 350) hist.removeFirst()
        if (now - lastFire < 700 || hist.size < 3) return
        val dx = p.x() - hist.first().second
        val dy = p.y() - hist.first().third
        if (max(abs(dx), abs(dy)) > 0.18f) {
            val dir = if (abs(dx) > abs(dy)) (if (dx > 0) "right" else "left") else (if (dy > 0) "down" else "up")
            lastFire = now
            hist.clear()
            onSwipe(dir)
        }
    }

    fun close() { try { landmarker.close() } catch (_: Exception) {} }
}
