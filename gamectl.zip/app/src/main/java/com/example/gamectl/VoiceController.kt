package com.example.gamectl

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

class VoiceController(private val ctx: Context, private val onCmd: (String) -> Unit) : RecognitionListener {
    private var svc: SpeechService? = null
    private val words = setOf("left", "right", "up", "down", "tap")

    fun start() {
        Thread {
            try {
                val dir = File(ctx.filesDir, "model")
                if (!File(dir, "uuid").exists()) copyAssets("model", dir)
                val model = Model(dir.absolutePath)
                val rec = Recognizer(model, 16000f, "[\"left\", \"right\", \"up\", \"down\", \"tap\", \"[unk]\"]")
                svc = SpeechService(rec, 16000f)
                svc?.startListening(this)
            } catch (e: Exception) { e.printStackTrace() }
        }.start()
    }

    private fun copyAssets(path: String, target: File) {
        val list = ctx.assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            target.parentFile?.mkdirs()
            try {
                ctx.assets.open(path).use { i -> target.outputStream().use { o -> i.copyTo(o) } }
            } catch (_: Exception) { target.mkdirs() }
        } else {
            target.mkdirs()
            for (n in list) copyAssets("$path/$n", File(target, n))
        }
    }

    fun stop() { try { svc?.stop(); svc?.shutdown() } catch (_: Exception) {} }

    override fun onResult(hypothesis: String?) {
        val t = try { JSONObject(hypothesis ?: "").optString("text") } catch (e: Exception) { "" }
        for (w in t.split(" ")) if (w in words) onCmd(w)
    }
    override fun onPartialResult(hypothesis: String?) {}
    override fun onFinalResult(hypothesis: String?) {}
    override fun onError(exception: Exception?) {}
    override fun onTimeout() {}
}
