package com.example.gamectl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.util.concurrent.Executors

class ControlService : LifecycleService() {
    private var hand: HandTracker? = null
    private var voice: VoiceController? = null
    private var provider: ProcessCameraProvider? = null
    private val exec = Executors.newSingleThreadExecutor()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ctl", "Game Control", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ctl")
            .setContentTitle("Game Control chal raha hai")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        ServiceCompat.startForeground(this, 1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (hand == null && intent?.getBooleanExtra("hand", true) == true) startHand()
        if (voice == null && intent?.getBooleanExtra("voice", true) == true) {
            voice = VoiceController(this) { GameAccessibilityService.act(it) }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun startHand() {
        val t = HandTracker(this) { GameAccessibilityService.act(it) }
        hand = t
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get(); provider = p
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(exec) { proxy ->
                try { t.detect(proxy) } catch (_: Exception) {} finally { proxy.close() }
            }
            p.unbindAll()
            p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        provider?.unbindAll()
        hand?.close()
        voice?.stop()
        exec.shutdown()
        super.onDestroy()
    }
}
