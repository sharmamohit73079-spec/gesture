package com.example.gamectl

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var cbHand: CheckBox
    private lateinit var cbVoice: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 18f
            setOnClickListener { f() }
            root.addView(this, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        status = TextView(this).apply { textSize = 18f }
        root.addView(status)
        btn("1. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        cbHand = CheckBox(this).apply { text = "Haath se control"; isChecked = true; textSize = 18f }
        cbVoice = CheckBox(this).apply { text = "Awaaz se control (left/right/up/down/tap)"; isChecked = true; textSize = 18f }
        root.addView(cbHand); root.addView(cbVoice)
        btn("2. START") { start() }
        btn("STOP") { startService(Intent(this, ControlService::class.java).setAction("STOP")) }
        val info = TextView(this).apply {
            textSize = 16f
            text = "\nSTART dabao, phir apna game kholo. Camera ke saamne haath ko left/right/up/down jhatka do, ya bolo: left, right, up, down, tap."
        }
        root.addView(info)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (GameAccessibilityService.instance != null) "Accessibility: ON \u2705" else "Accessibility: OFF \u274C (pehle button 1 dabao)"
    }

    private fun start() {
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        if (need.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(need, 1); return
        }
        startForegroundService(Intent(this, ControlService::class.java)
            .putExtra("hand", cbHand.isChecked).putExtra("voice", cbVoice.isChecked))
        Toast.makeText(this, "Chalu ho gaya. Ab game kholo.", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
    }
}
